import { Outlet, Link, useLocation } from 'react-router';
import { FileText, Home, Plus } from 'lucide-react';
import { Button } from './ui/button';

export function Layout() {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-8">
              <Link to="/" className="flex items-center gap-2">
                <FileText className="size-6 text-blue-600" />
                <span className="font-semibold text-xl">Quiz Builder</span>
              </Link>
              <nav className="hidden md:flex items-center gap-4">
                <Link to="/">
                  <Button
                    variant={location.pathname === '/' ? 'default' : 'ghost'}
                    size="sm"
                  >
                    <Home className="size-4 mr-2" />
                    Dashboard
                  </Button>
                </Link>
              </nav>
            </div>
            <Link to="/create">
              <Button>
                <Plus className="size-4 mr-2" />
                Create Quiz
              </Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>
    </div>
  );
}
