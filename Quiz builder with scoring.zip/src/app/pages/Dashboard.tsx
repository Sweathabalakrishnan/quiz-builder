import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { Plus, Edit, Trash2, Play, BarChart, FileText, Users, Share2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '../components/ui/alert-dialog';
import { ShareQuizDialog } from '../components/ShareQuizDialog';
import { quizStorage } from '../utils/storage-supabase';
import { Quiz } from '../types/quiz';
import { toast } from 'sonner';

export function Dashboard() {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null);
  const [loading, setLoading] = useState(true);
  const [attemptCounts, setAttemptCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    loadQuizzes();
  }, []);

  const loadQuizzes = async () => {
    try {
      setLoading(true);
      const data = await quizStorage.getQuizzes();
      setQuizzes(data);
      
      // Load attempt counts for all quizzes
      const counts: Record<string, number> = {};
      await Promise.all(
        data.map(async (quiz) => {
          const attempts = await quizStorage.getQuizAttempts(quiz.id);
          counts[quiz.id] = attempts.length;
        })
      );
      setAttemptCounts(counts);
    } catch (error) {
      console.error('Error loading quizzes:', error);
      toast.error('Failed to load quizzes');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await quizStorage.deleteQuiz(id);
      await loadQuizzes();
      toast.success('Quiz deleted successfully');
    } catch (error) {
      console.error('Error deleting quiz:', error);
      toast.error('Failed to delete quiz');
    }
  };

  const handleShare = (quiz: Quiz) => {
    setSelectedQuiz(quiz);
    setShareDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header with gradient background */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-8 shadow-xl">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10 flex items-center justify-between">
          <div className="text-white">
            <h1 className="text-4xl font-bold mb-2">My Quizzes</h1>
            <p className="text-indigo-100 text-lg">Create, edit, and manage your quizzes</p>
          </div>
          <div className="flex gap-3">
            <Link to="/student-results">
              <Button variant="outline" className="bg-white/20 backdrop-blur-sm text-white border-white/30 hover:bg-white/30">
                <Users className="size-4 mr-2" />
                Student Results
              </Button>
            </Link>
            <Link to="/create">
              <Button className="bg-white text-indigo-600 hover:bg-indigo-50 shadow-lg">
                <Plus className="size-4 mr-2" />
                Create Quiz
              </Button>
            </Link>
          </div>
        </div>
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/10 rounded-full blur-2xl -ml-24 -mb-24"></div>
      </div>

      {loading ? (
        <Card className="text-center py-16 shadow-lg border-0 bg-gradient-to-br from-white to-indigo-50">
          <CardContent>
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 text-white mb-6 shadow-xl">
              <FileText className="size-10" />
            </div>
            <h3 className="text-2xl font-semibold mb-3 text-gray-900">Loading...</h3>
            <p className="text-gray-600 mb-8 text-lg">
              Please wait while we load your quizzes
            </p>
          </CardContent>
        </Card>
      ) : quizzes.length === 0 ? (
        <Card className="text-center py-16 shadow-lg border-0 bg-gradient-to-br from-white to-indigo-50">
          <CardContent>
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 text-white mb-6 shadow-xl">
              <FileText className="size-10" />
            </div>
            <h3 className="text-2xl font-semibold mb-3 text-gray-900">No quizzes yet</h3>
            <p className="text-gray-600 mb-8 text-lg">
              Get started by creating your first quiz
            </p>
            <Link to="/create">
              <Button className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white px-8 py-6 text-lg shadow-xl">
                <Plus className="size-5 mr-2" />
                Create Your First Quiz
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizzes.map((quiz, index) => {
            const gradients = [
              'from-indigo-500 to-purple-500',
              'from-purple-500 to-pink-500',
              'from-pink-500 to-rose-500',
              'from-rose-500 to-orange-500',
              'from-orange-500 to-amber-500',
              'from-green-500 to-emerald-500',
              'from-cyan-500 to-blue-500',
              'from-blue-500 to-indigo-500',
            ];
            const gradient = gradients[index % gradients.length];
            
            return (
              <Card key={quiz.id} className="hover:shadow-2xl transition-all duration-300 border-0 overflow-hidden group hover:-translate-y-1">
                {/* Colorful header */}
                <div className={`h-2 bg-gradient-to-r ${gradient}`}></div>
                <CardHeader className="bg-gradient-to-br from-white to-gray-50">
                  <div className="flex items-start gap-3">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center text-white flex-shrink-0 shadow-lg`}>
                      <FileText className="size-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-xl mb-1">{quiz.title}</CardTitle>
                      <CardDescription className="text-sm">{quiz.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4 pt-6">
                  <div className="flex gap-4">
                    <div className="flex-1 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg p-3">
                      <p className="text-xs text-indigo-600 font-medium mb-1">Questions</p>
                      <p className="text-2xl font-bold text-indigo-700">{quiz.questions.length}</p>
                    </div>
                    <div className="flex-1 bg-gradient-to-br from-pink-50 to-rose-50 rounded-lg p-3">
                      <p className="text-xs text-pink-600 font-medium mb-1">Attempts</p>
                      <p className="text-2xl font-bold text-pink-700">{attemptCounts[quiz.id] || 0}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Link to={`/quiz/${quiz.id}`} className="flex-1">
                      <Button variant="default" className={`w-full bg-gradient-to-r ${gradient} text-white border-0 shadow-lg hover:shadow-xl transition-all`}>
                        <Play className="size-4 mr-2" />
                        Take Quiz
                      </Button>
                    </Link>
                    <Link to={`/edit/${quiz.id}`}>
                      <Button variant="outline" size="icon" className="hover:bg-indigo-50 hover:border-indigo-300 hover:text-indigo-600">
                        <Edit className="size-4" />
                      </Button>
                    </Link>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" size="icon" className="hover:bg-red-50 hover:border-red-300">
                          <Trash2 className="size-4 text-red-600" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Quiz</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete "{quiz.title}"? This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDelete(quiz.id)}>
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                    <Button variant="outline" size="icon" className="hover:bg-indigo-50 hover:border-indigo-300 hover:text-indigo-600" onClick={() => handleShare(quiz)}>
                      <Share2 className="size-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
      {selectedQuiz && (
        <ShareQuizDialog 
          open={shareDialogOpen} 
          onOpenChange={setShareDialogOpen} 
          quizId={selectedQuiz.id}
          quizTitle={selectedQuiz.title}
        />
      )}
    </div>
  );
}