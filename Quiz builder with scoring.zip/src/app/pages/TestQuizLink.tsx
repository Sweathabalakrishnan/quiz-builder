import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { CheckCircle, XCircle, Loader2, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router';
import { projectId, publicAnonKey } from '/utils/supabase/info';

interface TestResult {
  name: string;
  status: 'pending' | 'success' | 'error';
  message: string;
  details?: string;
}

export function TestQuizLink() {
  const navigate = useNavigate();
  const [testing, setTesting] = useState(false);
  const [tests, setTests] = useState<TestResult[]>([]);
  const [quizFound, setQuizFound] = useState(false);

  const specificQuizId = 'quiz-1776057211776';
  const apiBase = `https://${projectId}.supabase.co/functions/v1/make-server-994e9032`;

  const runTests = async () => {
    setTesting(true);
    setQuizFound(false);
    const results: TestResult[] = [];

    // Test 1: Health Check
    results.push({ name: 'Backend Health Check', status: 'pending', message: 'Testing...' });
    setTests([...results]);

    try {
      const healthResponse = await fetch(`${apiBase}/health`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
      });

      if (healthResponse.ok) {
        const data = await healthResponse.json();
        results[0] = {
          name: 'Backend Health Check',
          status: 'success',
          message: 'Backend server is online and responding',
          details: JSON.stringify(data),
        };
      } else {
        results[0] = {
          name: 'Backend Health Check',
          status: 'error',
          message: 'Backend server returned an error',
          details: `HTTP ${healthResponse.status}`,
        };
      }
    } catch (error) {
      results[0] = {
        name: 'Backend Health Check',
        status: 'error',
        message: 'Cannot connect to backend server',
        details: error instanceof Error ? error.message : 'Unknown error',
      };
      setTests([...results]);
      setTesting(false);
      return;
    }

    setTests([...results]);

    // Test 2: Get All Quizzes
    results.push({ name: 'Get All Quizzes', status: 'pending', message: 'Testing...' });
    setTests([...results]);

    try {
      const quizzesResponse = await fetch(`${apiBase}/quizzes`, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });

      if (quizzesResponse.ok) {
        const quizzes = await quizzesResponse.json();
        results[1] = {
          name: 'Get All Quizzes',
          status: 'success',
          message: `Found ${Array.isArray(quizzes) ? quizzes.length : 0} quiz(es) in database`,
          details: quizzes.map((q: any) => `${q.title} (${q.id})`).join(', '),
        };
      } else {
        results[1] = {
          name: 'Get All Quizzes',
          status: 'error',
          message: 'Failed to fetch quizzes',
          details: `HTTP ${quizzesResponse.status}`,
        };
      }
    } catch (error) {
      results[1] = {
        name: 'Get All Quizzes',
        status: 'error',
        message: 'Quiz API failed',
        details: error instanceof Error ? error.message : 'Unknown error',
      };
    }

    setTests([...results]);

    // Test 3: Get Specific Quiz
    results.push({
      name: 'Get Your Specific Quiz',
      status: 'pending',
      message: `Checking quiz: ${specificQuizId}...`,
    });
    setTests([...results]);

    try {
      const quizResponse = await fetch(`${apiBase}/quizzes/${specificQuizId}`, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });

      if (quizResponse.ok) {
        const quiz = await quizResponse.json();
        if (quiz && quiz.title) {
          results[2] = {
            name: 'Get Your Specific Quiz',
            status: 'success',
            message: `🎉 SUCCESS! Quiz found: "${quiz.title}"`,
            details: `${quiz.questions?.length || 0} questions • Created: ${new Date(
              quiz.createdAt
            ).toLocaleString()}`,
          };
          setQuizFound(true);
        } else {
          results[2] = {
            name: 'Get Your Specific Quiz',
            status: 'error',
            message: 'Quiz not found in backend database',
            details: 'Quiz was saved locally only, not in cloud. Recreate it.',
          };
        }
      } else if (quizResponse.status === 404) {
        results[2] = {
          name: 'Get Your Specific Quiz',
          status: 'error',
          message: 'Quiz does not exist in backend',
          details: 'You need to create the quiz again (backend is now ready)',
        };
      } else {
        results[2] = {
          name: 'Get Your Specific Quiz',
          status: 'error',
          message: 'Failed to get quiz',
          details: `HTTP ${quizResponse.status}`,
        };
      }
    } catch (error) {
      results[2] = {
        name: 'Get Your Specific Quiz',
        status: 'error',
        message: 'Request failed',
        details: error instanceof Error ? error.message : 'Unknown error',
      };
    }

    setTests([...results]);
    setTesting(false);
  };

  const allPassed = tests.length > 0 && tests.every((t) => t.status === 'success');

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
          <ArrowLeft className="size-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold">🔍 Test Your Quiz Link</h1>
          <p className="text-gray-600">
            Testing quiz ID: <code className="bg-gray-100 px-2 py-1 rounded">{specificQuizId}</code>
          </p>
        </div>
        <Button onClick={runTests} disabled={testing}>
          {testing ? (
            <>
              <Loader2 className="size-4 mr-2 animate-spin" />
              Testing...
            </>
          ) : (
            'Run Tests'
          )}
        </Button>
      </div>

      {tests.length === 0 && (
        <Card>
          <CardContent className="pt-12 pb-12 text-center">
            <p className="text-gray-600 mb-4">Click "Run Tests" to check if your quiz link works</p>
            <Button onClick={runTests} size="lg">
              ▶️ Start Testing
            </Button>
          </CardContent>
        </Card>
      )}

      {tests.length > 0 && (
        <div className="space-y-4">
          {tests.map((test, idx) => (
            <Card
              key={idx}
              className={`border-l-4 ${
                test.status === 'success'
                  ? 'border-l-green-500 bg-green-50'
                  : test.status === 'error'
                  ? 'border-l-red-500 bg-red-50'
                  : 'border-l-blue-500 bg-blue-50'
              }`}
            >
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  {test.status === 'success' ? (
                    <CheckCircle className="size-6 text-green-600 mt-0.5 shrink-0" />
                  ) : test.status === 'error' ? (
                    <XCircle className="size-6 text-red-600 mt-0.5 shrink-0" />
                  ) : (
                    <Loader2 className="size-6 text-blue-600 mt-0.5 shrink-0 animate-spin" />
                  )}
                  <div className="flex-1">
                    <p
                      className={`font-semibold mb-1 ${
                        test.status === 'success'
                          ? 'text-green-900'
                          : test.status === 'error'
                          ? 'text-red-900'
                          : 'text-blue-900'
                      }`}
                    >
                      {test.name}
                    </p>
                    <p
                      className={`text-sm ${
                        test.status === 'success'
                          ? 'text-green-700'
                          : test.status === 'error'
                          ? 'text-red-700'
                          : 'text-blue-700'
                      }`}
                    >
                      {test.message}
                    </p>
                    {test.details && (
                      <p
                        className={`text-xs mt-2 font-mono ${
                          test.status === 'success'
                            ? 'text-green-600'
                            : test.status === 'error'
                            ? 'text-red-600'
                            : 'text-blue-600'
                        }`}
                      >
                        {test.details}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {allPassed && quizFound && (
            <Card className="border-l-4 border-l-green-500 bg-gradient-to-br from-green-50 to-emerald-50">
              <CardHeader>
                <CardTitle className="text-green-900">🎉 All Tests Passed!</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-green-800 font-semibold">Your quiz link is working perfectly!</p>
                <div className="bg-white p-4 rounded-lg">
                  <p className="text-sm text-gray-600 mb-2">Share this link with students:</p>
                  <code className="text-sm bg-gray-100 p-3 rounded block break-all">
                    https://60a122b3-342d-4b00-bb7b-7ca28f4170ea-v3-figmaiframepreview.figma.site/quiz/{specificQuizId}
                  </code>
                </div>
                <div className="bg-white p-4 rounded-lg">
                  <p className="font-semibold text-green-900 mb-2">Students can now:</p>
                  <ul className="space-y-1 text-sm text-green-800">
                    <li>✅ Open this link from any browser</li>
                    <li>✅ Access from any device (phone, tablet, computer)</li>
                    <li>✅ Take the quiz and submit answers</li>
                    <li>✅ Get instant results</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          )}

          {tests.some((t) => t.status === 'error') && !allPassed && (
            <Card className="border-l-4 border-l-orange-500 bg-orange-50">
              <CardHeader>
                <CardTitle className="text-orange-900">🔧 Action Required</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {tests[0]?.status === 'error' && (
                  <div>
                    <p className="font-semibold text-orange-900 mb-2">Backend Not Deployed:</p>
                    <ol className="list-decimal ml-5 space-y-2 text-sm text-orange-800">
                      <li>
                        Go to:{' '}
                        <a
                          href="https://supabase.com/dashboard/project/ecihrubcueotcqmosqti/functions"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="underline font-semibold"
                        >
                          Supabase Functions
                        </a>
                      </li>
                      <li>Click on: make-server-994e9032</li>
                      <li>Click "Deploy" button</li>
                      <li>Wait for success message (15-30 seconds)</li>
                      <li>Come back and click "Run Tests" again</li>
                    </ol>
                  </div>
                )}
                {tests[0]?.status === 'success' && tests[2]?.status === 'error' && (
                  <div>
                    <p className="font-semibold text-orange-900 mb-2">Quiz Not in Database:</p>
                    <ol className="list-decimal ml-5 space-y-2 text-sm text-orange-800">
                      <li>Go back to your quiz app Dashboard</li>
                      <li>Click "Create New Quiz"</li>
                      <li>You should see "✓ Connected to backend" in green</li>
                      <li>Fill in quiz details and questions</li>
                      <li>Click "Save Quiz"</li>
                      <li>Get the new share link</li>
                      <li>The new link will work for everyone! 🎉</li>
                    </ol>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
